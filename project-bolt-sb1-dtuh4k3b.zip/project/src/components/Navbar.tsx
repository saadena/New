import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Home, Search, User, Menu } from 'lucide-react';
import LanguageSwitcher from './LanguageSwitcher';
import { useAuth } from '../contexts/AuthContext';

const Navbar = () => {
  const { t } = useTranslation();
  const { user, isAdmin } = useAuth();

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Home className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-2xl font-bold text-indigo-600">3ndek</span>
            </Link>
          </div>

          <div className="hidden sm:flex sm:items-center sm:space-x-8">
            <Link to="/properties" className="text-gray-700 hover:text-indigo-600">
              {t('properties')}
            </Link>
            {isAdmin && (
              <Link to="/admin" className="text-gray-700 hover:text-indigo-600">
                {t('admin')}
              </Link>
            )}
            <LanguageSwitcher />
            {user ? (
              <Link to="/profile" className="flex items-center text-gray-700 hover:text-indigo-600">
                <User className="h-5 w-5 mr-1" />
                {t('profile')}
              </Link>
            ) : (
              <Link to="/login" className="text-gray-700 hover:text-indigo-600">
                {t('login')}
              </Link>
            )}
          </div>

          <div className="sm:hidden flex items-center">
            <button className="text-gray-700">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar