import React from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { MapPin, Bed, Bath, Square, Star, Phone, Mail } from 'lucide-react';

const PropertyDetails = () => {
  const { id } = useParams();
  const { t } = useTranslation();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="md:col-span-2">
          {/* Image Gallery */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&q=80&w=800"
              alt="Property"
              className="w-full h-[400px] object-cover"
            />
          </div>

          {/* Property Details */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold mb-4">Sample Property Title</h1>
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin className="w-5 h-5 mr-2" />
              <span>123 Sample Street, City, Country</span>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="flex items-center">
                <Bed className="w-5 h-5 mr-2 text-indigo-600" />
                <span>3 {t('property.bedrooms')}</span>
              </div>
              <div className="flex items-center">
                <Bath className="w-5 h-5 mr-2 text-indigo-600" />
                <span>2 {t('property.bathrooms')}</span>
              </div>
              <div className="flex items-center">
                <Square className="w-5 h-5 mr-2 text-indigo-600" />
                <span>150m²</span>
              </div>
            </div>

            <h2 className="text-xl font-semibold mb-3">{t('property.description')}</h2>
            <p className="text-gray-600 mb-6">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>

            <h2 className="text-xl font-semibold mb-3">{t('property.features')}</h2>
            <ul className="grid grid-cols-2 gap-2 text-gray-600 mb-6">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></span>
                Feature 1
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></span>
                Feature 2
              </li>
              {/* Add more features */}
            </ul>
          </div>

          {/* Reviews Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">{t('property.reviews')}</h2>
            <div className="space-y-4">
              {[1, 2].map((review) => (
                <div key={review} className="border-b pb-4">
                  <div className="flex items-center mb-2">
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${star <= 4 ? 'text-yellow-400' : 'text-gray-300'}`}
                          fill={star <= 4 ? 'currentColor' : 'none'}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-gray-600">User Name</span>
                  </div>
                  <p className="text-gray-600">Sample review text...</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="md:col-span-1">
          {/* Price Card */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="text-3xl font-bold text-indigo-600 mb-4">$250,000</div>
            <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 mb-4">
              {t('property.book')}
            </button>
          </div>

          {/* Contact Card */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">{t('property.contact')}</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <Phone className="w-5 h-5 text-indigo-600 mr-2" />
                <span>+1 234 567 890</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-5 h-5 text-indigo-600 mr-2" />
                <span>contact@example.com</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetails;