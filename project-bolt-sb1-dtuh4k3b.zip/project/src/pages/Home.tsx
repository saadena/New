import React from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Building, Home as HomeIcon, BedDouble } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  const { t } = useTranslation();

  return (
    <div>
      {/* Hero Section */}
      <div 
        className="relative h-[600px] bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative max-w-7xl mx-auto px-4 h-full flex flex-col justify-center items-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold text-center mb-6">
            {t('home.title')}
          </h1>
          <p className="text-xl md:text-2xl text-center mb-8">
            {t('home.subtitle')}
          </p>
          
          {/* Search Bar */}
          <div className="w-full max-w-3xl bg-white rounded-lg shadow-lg p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                placeholder={t('home.searchPlaceholder')}
                className="flex-grow px-4 py-2 border rounded text-gray-800"
              />
              <button className="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 flex items-center justify-center">
                <Search className="w-5 h-5 mr-2" />
                {t('filters.search')}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Property Types Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">{t('propertyTypes.title', 'Property Types')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Building, type: 'land', color: 'bg-emerald-100 text-emerald-600' },
            { icon: HomeIcon, type: 'house', color: 'bg-blue-100 text-blue-600' },
            { icon: BedDouble, type: 'room', color: 'bg-purple-100 text-purple-600' }
          ].map(({ icon: Icon, type, color }) => (
            <Link
              key={type}
              to={`/properties?type=${type}`}
              className="group p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow"
            >
              <div className={`w-16 h-16 ${color} rounded-full flex items-center justify-center mb-4`}>
                <Icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {t(`propertyTypes.${type}`)}
              </h3>
              <p className="text-gray-600">
                {t(`propertyTypes.${type}Description`, 'Explore available properties')}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;