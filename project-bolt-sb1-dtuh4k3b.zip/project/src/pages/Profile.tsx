import React from 'react';
import { useTranslation } from 'react-i18next';
import { User, Mail, Phone, Star, Building2, Calendar } from 'lucide-react';

const Profile = () => {
  const { t } = useTranslation();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Info */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <User className="w-12 h-12 text-indigo-600" />
              </div>
              <h2 className="text-xl font-semibold mb-2">John Doe</h2>
              <div className="flex items-center text-gray-600 mb-4">
                <Mail className="w-4 h-4 mr-2" />
                <span>john@example.com</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Phone className="w-4 h-4 mr-2" />
                <span>+1 234 567 890</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2">
          {/* My Properties */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Building2 className="w-5 h-5 mr-2" />
              {t('profile.myProperties')}
            </h3>
            <div className="space-y-4">
              {[1, 2].map((property) => (
                <div key={property} className="border rounded-lg p-4">
                  <div className="flex items-start">
                    <img
                      src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&q=80&w=200"
                      alt="Property"
                      className="w-24 h-24 object-cover rounded"
                    />
                    <div className="ml-4 flex-grow">
                      <h4 className="font-semibold">Property Title {property}</h4>
                      <p className="text-gray-600">Location</p>
                      <div className="mt-2 flex justify-between items-center">
                        <span className="text-indigo-600 font-semibold">$250,000</span>
                        <button className="text-indigo-600 hover:text-indigo-800">
                          {t('profile.edit')}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* My Bookings */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              {t('profile.myBookings')}
            </h3>
            <div className="space-y-4">
              {[1, 2].map((booking) => (
                <div key={booking} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold">Booking #{booking}</h4>
                      <p className="text-gray-600">Property Name</p>
                      <p className="text-sm text-gray-500">March 15, 2025 - March 20, 2025</p>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-green-100 text-green-800">
                      Active
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* My Reviews */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Star className="w-5 h-5 mr-2" />
              {t('profile.myReviews')}
            </h3>
            <div className="space-y-4">
              {[1, 2].map((review) => (
                <div key={review} className="border rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${star <= 4 ? 'text-yellow-400' : 'text-gray-300'}`}
                          fill={star <= 4 ? 'currentColor' : 'none'}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-gray-600">Property Name</span>
                  </div>
                  <p className="text-gray-600">
                    Sample review text...
                  </p>
                  <p className="text-sm text-gray-500 mt-2">March 10, 2025</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;