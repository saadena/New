import React from 'react';
import { useTranslation } from 'react-i18next';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Building2, Users, Calendar, Settings } from 'lucide-react';

// Admin sub-pages
const Dashboard = () => {
  const { t } = useTranslation();
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Stats Cards */}
      {[
        { title: 'Total Properties', value: '150', color: 'bg-blue-500' },
        { title: 'Active Bookings', value: '45', color: 'bg-green-500' },
        { title: 'Total Users', value: '1,234', color: 'bg-purple-500' }
      ].map((stat) => (
        <div key={stat.title} className={`${stat.color} text-white rounded-lg p-6`}>
          <h3 className="text-lg font-semibold">{t(`admin.${stat.title}`)}</h3>
          <p className="text-3xl font-bold">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};

const Properties = () => {
  const { t } = useTranslation();
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">{t('admin.properties')}</h2>
      {/* Property management table/list will go here */}
    </div>
  );
};

const UserManagement = () => {
  const { t } = useTranslation();
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">{t('admin.users')}</h2>
      {/* User management table/list will go here */}
    </div>
  );
};

const Bookings = () => {
  const { t } = useTranslation();
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">{t('admin.bookings')}</h2>
      {/* Booking management table/list will go here */}
    </div>
  );
};

const SettingsPanel = () => {
  const { t } = useTranslation();
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">{t('admin.settings')}</h2>
      {/* Settings form will go here */}
    </div>
  );
};

const Admin = () => {
  const { t } = useTranslation();
  const location = useLocation();

  const navItems = [
    { path: '', icon: LayoutDashboard, label: 'Dashboard' },
    { path: 'properties', icon: Building2, label: 'Properties' },
    { path: 'users', icon: Users, label: 'Users' },
    { path: 'bookings', icon: Calendar, label: 'Bookings' },
    { path: 'settings', icon: Settings, label: 'Settings' }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Admin Navigation */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <nav className="flex space-x-4">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={`/admin/${path}`}
                className={`flex items-center px-4 py-2 rounded-lg ${
                  location.pathname === `/admin/${path}`
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5 mr-2" />
                {t(`admin.${label.toLowerCase()}`)}
              </Link>
            ))}
          </nav>
        </div>

        {/* Admin Content */}
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/properties" element={<Properties />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/settings" element={<SettingsPanel />} />
        </Routes>
      </div>
    </div>
  );
};

export default Admin;