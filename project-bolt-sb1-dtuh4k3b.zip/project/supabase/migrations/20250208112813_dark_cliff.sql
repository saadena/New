/*
  # Initial Schema for 3ndek Real Estate Platform

  1. New Tables
    - `properties`
      - Basic property information
      - Location and pricing details
      - Property type and status
    - `reviews`
      - Property reviews and ratings
    - `bookings`
      - Booking records for properties
    - `users`
      - Extended user profile information
    
  2. Security
    - RLS enabled on all tables
    - Policies for read/write access
*/

-- Create custom types
CREATE TYPE property_type AS ENUM ('land', 'house', 'room');
CREATE TYPE property_status AS ENUM ('for_sale', 'for_rent', 'available');

-- Create properties table
CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title jsonb NOT NULL, -- Multilingual titles {en: "", fr: "", ar: ""}
  description jsonb NOT NULL, -- Multilingual descriptions
  property_type property_type NOT NULL,
  status property_status NOT NULL,
  price decimal NOT NULL,
  size_sqm decimal NOT NULL,
  bedrooms int,
  bathrooms int,
  location_lat decimal NOT NULL,
  location_lng decimal NOT NULL,
  address jsonb NOT NULL, -- Multilingual addresses
  images text[] NOT NULL,
  features jsonb NOT NULL, -- Multilingual features list
  owner_id uuid REFERENCES auth.users NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties NOT NULL,
  user_id uuid REFERENCES auth.users NOT NULL,
  rating int NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties NOT NULL,
  user_id uuid REFERENCES auth.users NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  total_price decimal NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create extended user profiles
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users,
  full_name text,
  phone text,
  is_admin boolean DEFAULT false,
  preferred_language text DEFAULT 'en',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Properties policies
CREATE POLICY "Anyone can view properties" ON properties
  FOR SELECT USING (true);

CREATE POLICY "Users can create properties" ON properties
  FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners can update their properties" ON properties
  FOR UPDATE USING (auth.uid() = owner_id);

-- Reviews policies
CREATE POLICY "Anyone can view reviews" ON reviews
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create reviews" ON reviews
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Bookings policies
CREATE POLICY "Users can view their own bookings" ON bookings
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings" ON bookings
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Profiles policies
CREATE POLICY "Users can view profiles" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Functions
CREATE OR REPLACE FUNCTION calculate_average_rating(property_uuid uuid)
RETURNS decimal AS $$
  SELECT COALESCE(AVG(rating), 0)
  FROM reviews
  WHERE property_id = property_uuid;
$$ LANGUAGE SQL;